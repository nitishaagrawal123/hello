package HotelBookingLogin;

import static org.junit.Assert.assertEquals;
import static org.testng.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import HotelBookingPageBean.HotelBookingPageFactory;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefLog {
	private WebDriver driver;
	private HotelBookingPageFactory objhbpg;
	
	@Given("^User is on hotel booking login page$")
	public void user_is_on_hotel_booking_login_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\NITISHAG\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objhbpg = new HotelBookingPageFactory(driver);
		driver.get("file:\\\\C:\\Users\\NITISHAG\\Desktop\\mod\\login.html");
	}

	@Then("^Check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		String title = driver.getTitle();
		String pageHeading = driver.findElement(By.xpath("//*[@id='mainCnt']/div/div[1]/h1")).getText();
		System.out.println("Title is : " + pageHeading);

		if (title.contentEquals("login"))
			System.out.println("****** Title Matched******");
		else
			System.out.println("****** Title NOT Matched******");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.close();
	}

	@When("^User leaves User Name blank$")
	public void user_leaves_User_Name_blank() throws Throwable {
		objhbpg.setPfusername("");
		Thread.sleep(1000);
	}

	@When("^Clicks the button$")
	public void clicks_the_button() throws Throwable {
		objhbpg.setPfbutton();
	}

	@Then("^Display alert msgss$")
	public void display_alert_msgss() throws Throwable {
		String alertMessage = driver.findElement(By.xpath("//*[@id='userErrMsg']")).getText();
		Thread.sleep(1000);
		// driver.switchTo().alert().accept();
		System.out.println("******" + alertMessage);
		// driver.close();
	}

	@When("^User leaves password blank$")
	public void user_leaves_password_blank() throws Throwable {
		objhbpg.setPfusername("capgemini");
		Thread.sleep(1000);
		objhbpg.setPfuserpwd("");
		Thread.sleep(1000);
		objhbpg.setPfbutton();
	}

	@Then("^Display alert msgs$")
	public void display_alert_msgs() throws Throwable {
		String alertMessage = driver.findElement(By.xpath("//*[@id='pwdErrMsg']")).getText();
		Thread.sleep(1000);
		// driver.switchTo().alert().accept();
		System.out.println("******" + alertMessage);
	}

	@When("^User enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
		objhbpg.setPfusername("capgemini");
		Thread.sleep(1000);
		objhbpg.setPfuserpwd("capg1234");
		Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		objhbpg.setPfbutton();
		Thread.sleep(1000);
	}

	@Then("^Navigate to hotel booking form page$")
	public void navigate_to_hotel_booking_form_page() throws Throwable {
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}
	
//After successful login, hotel booking form page will be displayed and testing continues. 
	
	@Given("^User is on hotel booking form page$")
	public void user_is_on_hotel_booking_form_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\NITISHAG\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objhbpg = new HotelBookingPageFactory(driver);
		driver.get("file:\\\\C:\\Users\\NITISHAG\\Desktop\\mod\\hotelbooking.html");
	}

	@Then("^check the page heading of the page$")
	public void check_the_page_heading_of_the_page() throws Throwable {
		String title=driver.getTitle();
		if(title.contentEquals("Hotel Booking")) 
			System.out.println("****** Title Matched ******");
		else 
			System.out.println("****** Title NOT Matched ******");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user leaves first Name blank$")
	public void user_leaves_first_Name_blank() throws Throwable {
		objhbpg.setPffname("");	
		Thread.sleep(1000);
	}

	@When("^click the button$")
	public void click_the_button() throws Throwable {
		objhbpg.setPfconfirm();
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.close();
	}

	@When("^user leaves last Name blank$")
	public void user_leaves_last_Name_blank() throws Throwable {
		objhbpg.setPffname("Nitisha");	
		Thread.sleep(1000);
		objhbpg.setPflname("");	
		Thread.sleep(1000);
		//objhbpg.setPfconfirm();
	}

	@When("^user enters all data$")
	public void user_enters_all_data() throws Throwable {
		objhbpg.setPffname("Nitisha");	
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");	
		Thread.sleep(1000);
		objhbpg.setPfmobile("9897496567");	
		Thread.sleep(1000);
		objhbpg.setPfcity("Pune");	
		Thread.sleep(1000);
		objhbpg.setPfstate("Maharashtra");	
		Thread.sleep(1000);
		objhbpg.setPfpersons(3);	
		Thread.sleep(1000);
		objhbpg.setPfcardholder("Nitisha Agrawal");	
		Thread.sleep(1000);
		objhbpg.setPfdebit("5671234567899876");	
		Thread.sleep(1000);
		objhbpg.setPfcvv("056");	
		Thread.sleep(1000);
		objhbpg.setPfmonth("9");	
		Thread.sleep(1000);
		objhbpg.setPfyear("2020");	
		Thread.sleep(1000);
	}

	@When("^user enters incorrect email format$")
	public void user_enters_incorrect_email_format() throws Throwable {
		objhbpg.setPfemail("Rk2@.com");	
		Thread.sleep(1000);
		//objhbpg.setPfconfirm();
	}

	@When("^user leaves MobileNo blank$")
	public void user_leaves_MobileNo_blank() throws Throwable {
		objhbpg.setPffname("Nitisha");	
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");	
		Thread.sleep(1000);
		objhbpg.setPfemail("nitisha.k@gmail.com");	
		Thread.sleep(1000);
		objhbpg.setPfmobile("");	
		Thread.sleep(1000);
		//objhbpg.setPfconfirm();
	}

	@When("^user doesnot select city$")
	public void user_doesnot_select_city() throws Throwable {
		objhbpg.setPffname("Nitisha");	
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");	
		Thread.sleep(1000);
		objhbpg.setPfemail("nitisha.k@gmail.com");	
		Thread.sleep(1000);
		objhbpg.setPfmobile("9897496567");	
		Thread.sleep(1000);
		objhbpg.setPfcity("Select City");	
		Thread.sleep(1000);
		objhbpg.setPfconfirm();
	}

	@When("^user doesnot select state$")
	public void user_doesnot_select_state() throws Throwable {
		objhbpg.setPffname("Nitisha");	
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");	
		Thread.sleep(1000);
		objhbpg.setPfemail("nitu.k@gmail.com");	
		Thread.sleep(1000);
		objhbpg.setPfmobile("9897496567");	
		Thread.sleep(1000);
		objhbpg.setPfcity("Pune");	
		Thread.sleep(1000);
		objhbpg.setPfstate("Select State");	
		Thread.sleep(1000);
		objhbpg.setPfconfirm();
	}

	@When("^user enters (\\d+)$")
	public void user_enters(int arg1) throws Throwable {
		objhbpg.setPffname("Nitisha");	
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");	
		Thread.sleep(1000);
		objhbpg.setPfemail("nitisha.k@gmail.com");	
		Thread.sleep(1000);
		objhbpg.setPfmobile("9897496567");	
		Thread.sleep(1000);
		objhbpg.setPfcity("Pune");	
		Thread.sleep(1000);
		objhbpg.setPfstate("Maharashtra");	
		Thread.sleep(1000);
		objhbpg.setPfpersons(arg1);	
		Thread.sleep(2000);
	}

	@Then("^allocate rooms such that (\\d+) room for minimum (\\d+) guests$")
	public void allocate_rooms_such_that_room_for_minimum_guests(int arg1, int arg2) throws Throwable {
		if(arg2 <=3) {
	    	System.out.println("***** 1 room");
	    	assertEquals(1, arg1);
	    }
	    else if(arg2 <=6){
	    	System.out.println("***** 2 rooms");
	    	assertEquals(2, arg1); 	
	    }	 
	    else if(arg2 <=9){
	    	System.out.println("***** 3 rooms");
	    	assertEquals(3, arg1); 	
	    }
	}

	@When("^user leaves CardHolderName blank$")
	public void user_leaves_CardHolderName_blank() throws Throwable {
		objhbpg.setPffname("Nitisha");	
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");	
		Thread.sleep(1000);
		objhbpg.setPfemail("nitisha.k@gmail.com");	
		Thread.sleep(1000);
		objhbpg.setPfmobile("9897496567");	
		Thread.sleep(1000);
		objhbpg.setPfcity("Pune");	
		Thread.sleep(1000);
		objhbpg.setPfstate("Maharashtra");	
		Thread.sleep(1000);
		objhbpg.setPfpersons(3);	
		Thread.sleep(1000);
		objhbpg.setPfcardholder("");	
		Thread.sleep(1000);
		//objhbpg.setPfconfirm();
	}

	@When("^user leaves DebitCardNo blank$")
	public void user_leaves_DebitCardNo_blank() throws Throwable {
		objhbpg.setPffname("Nitisha");	
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");	
		Thread.sleep(1000);
		objhbpg.setPfemail("nitisha.k@gmail.com");	
		Thread.sleep(1000);
		objhbpg.setPfmobile("9897496567");	
		Thread.sleep(1000);
		objhbpg.setPfcity("Pune");	
		Thread.sleep(1000);
		objhbpg.setPfstate("Maharashtra");	
		Thread.sleep(1000);
		objhbpg.setPfpersons(3);	
		Thread.sleep(1000);
		objhbpg.setPfcardholder("Rutuja Kulkarni");	
		Thread.sleep(1000);
		objhbpg.setPfdebit("");	
		Thread.sleep(1000);
		//objhbpg.setPfconfirm();
	}

	@When("^user leaves expirationMonth blank$")
	public void user_leaves_expirationMonth_blank() throws Throwable {
		objhbpg.setPffname("Nitisha");	
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");	
		Thread.sleep(1000);
		objhbpg.setPfemail("nitisha.k@gmail.com");	
		Thread.sleep(1000);
		objhbpg.setPfmobile("9897496567");	
		Thread.sleep(1000);
		objhbpg.setPfcity("Pune");	
		Thread.sleep(1000);
		objhbpg.setPfstate("Maharashtra");	
		Thread.sleep(1000);
		objhbpg.setPfpersons(3);	
		Thread.sleep(1000);
		objhbpg.setPfcardholder("Nitisha Agrawal");	
		Thread.sleep(1000);
		objhbpg.setPfdebit("8765431234567898");	
		Thread.sleep(1000);
		objhbpg.setPfcvv("098");	
		Thread.sleep(1000);
		objhbpg.setPfmonth("");	
		Thread.sleep(1000);
		//objhbpg.setPfconfirm();
	}

	@When("^user leaves expirationYr blank$")
	public void user_leaves_expirationYr_blank() throws Throwable {
		objhbpg.setPffname("Nitisha");	
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");	
		Thread.sleep(1000);
		objhbpg.setPfemail("nitu.k@gmail.com");	
		Thread.sleep(1000);
		objhbpg.setPfmobile("9897496567");	
		Thread.sleep(1000);
		objhbpg.setPfcity("Pune");	
		Thread.sleep(1000);
		objhbpg.setPfstate("Maharashtra");	
		Thread.sleep(1000);
		objhbpg.setPfpersons(3);	
		Thread.sleep(1000);
		objhbpg.setPfcardholder("Nitisha Agrawal");	
		Thread.sleep(1000);
		objhbpg.setPfdebit("7678567867897890");
		Thread.sleep(1000);
		objhbpg.setPfcvv("056");	
		Thread.sleep(1000);
		objhbpg.setPfmonth("8");	
		Thread.sleep(1000);
		objhbpg.setPfyear("");	
		Thread.sleep(1000);
		//objhbpg.setPfconfirm();
	}

	@When("^user enter all valid data$")
	public void user_enter_all_valid_data() throws Throwable {
		objhbpg.setPffname("Nitisha");	
		Thread.sleep(1000);
		objhbpg.setPflname("Agrawal");	
		Thread.sleep(1000);
		objhbpg.setPfemail("nitishagarg123@gmail.com");	
		Thread.sleep(1000);
		objhbpg.setPfmobile("9897496567");	
		Thread.sleep(1000);
		objhbpg.setPfcity("Pune");	
		Thread.sleep(1000);
		objhbpg.setPfstate("Maharashtra");	
		Thread.sleep(1000);
		objhbpg.setPfpersons(3);	
		Thread.sleep(1000);
		objhbpg.setPfcardholder("Nitisha Agrawal");	
		Thread.sleep(1000);
		objhbpg.setPfdebit("5678567867897890");	
		Thread.sleep(1000);
		objhbpg.setPfcvv("067");	
		Thread.sleep(1000);
		objhbpg.setPfmonth("9");	
		Thread.sleep(1000);
		objhbpg.setPfyear("2020"); 
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		//objhbpg.setPfconfirm();
		Thread.sleep(1000);
	}

	@Then("^navigate to success page$")
	public void navigate_to_success_page() throws Throwable {
		driver.navigate().to("file:\\C:\\Users\\NITISHAG\\Desktop\\mod\\success.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();

	}

}
