package com.capgemini.repository;

import org.springframework.data.repository.CrudRepository;

import com.capgemini.bean.Customer;

public interface AccountRepo {
	
	public Customer findById(String id);
	public Customer save(Customer customer);
 	

}
