package com.capgemini.repository;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.bean.Customer;

@Repository
@Transactional
public class AccountRepoImpl implements AccountRepo {
    
	@PersistenceContext 
	EntityManager entityManager;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	@Transactional
	@Override
	public Customer findById(String id) {
		
		
		return entityManager.find(Customer.class, id);
	}
	@Transactional
	@Override
	public Customer save(Customer customer) {
		entityManager.persist(customer);
		// TODO Auto-generated method stub
		return customer;
	}

}
