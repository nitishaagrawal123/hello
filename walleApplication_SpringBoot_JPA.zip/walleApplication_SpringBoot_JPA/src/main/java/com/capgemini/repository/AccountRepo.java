package com.capgemini.repository;

import org.springframework.data.repository.CrudRepository;

import com.capgemini.bean.Customer;

public interface AccountRepo extends CrudRepository<Customer, String> {

}
